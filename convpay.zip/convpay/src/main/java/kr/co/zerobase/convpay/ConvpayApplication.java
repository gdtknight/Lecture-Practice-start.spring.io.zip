package kr.co.zerobase.convpay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConvpayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConvpayApplication.class, args);
	}

}
