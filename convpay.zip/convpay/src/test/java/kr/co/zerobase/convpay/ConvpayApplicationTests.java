package kr.co.zerobase.convpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConvpayApplicationTests {

	@Test
	void contextLoads() {
	}

}
